/**
 * Fetch app icons from Google Play listing pages into assets/apps/.
 * Run from the repository root: node scripts/fetch-app-icons.mjs
 *
 * The Google Play listing's og:image is used where available.
 * If a listing changes its markup, download that icon manually and keep
 * the same filename referenced in README.md.
 */
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";

const apps = [
  ["typemate", "com.typemate.ai"],
  ["notecalc", "com.zaynmiraj.calmaster"],
  ["safiora", "com.safiora.vpn"],
  ["sportsnest", "com.sportsnest.app"],
  ["payx-hub", "com.saithy.paymentxhub"],
  ["payx-bic", "com.paymentx.bic"],
];

const outputDir = path.resolve("assets/apps");
await mkdir(outputDir, { recursive: true });

for (const [filename, packageId] of apps) {
  const pageUrl = `https://play.google.com/store/apps/details?id=${packageId}&hl=en`;
  try {
    const response = await fetch(pageUrl, {
      headers: { "user-agent": "Mozilla/5.0 (compatible; ProfileAssetFetcher/1.0)" },
    });
    if (!response.ok) throw new Error(`Google Play returned HTTP ${response.status}`);
    const html = await response.text();
    const match =
      html.match(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i) ||
      html.match(/<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:image["']/i);
    if (!match) throw new Error("Could not find the listing's og:image metadata");
    const imageUrl = match[1].replaceAll("&amp;", "&");
    const imageResponse = await fetch(imageUrl);
    if (!imageResponse.ok) throw new Error(`Icon download returned HTTP ${imageResponse.status}`);
    const contentType = imageResponse.headers.get("content-type") || "";
    if (!contentType.startsWith("image/")) throw new Error(`Unexpected image content type: ${contentType}`);
    const extension = contentType.includes("png") ? ".png" : ".jpg";
    const filePath = path.join(outputDir, `${filename}${extension}`);
    await writeFile(filePath, Buffer.from(await imageResponse.arrayBuffer()));
    console.log(`Saved ${filePath}`);
  } catch (error) {
    console.error(`Skipped ${packageId}: ${error.message}`);
  }
}
