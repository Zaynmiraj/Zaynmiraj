# Profile image assets

The README references app icon files in `assets/apps/`.

1. Run `node scripts/fetch-app-icons.mjs` from the repository root to fetch the six known Google Play icons.
2. For apps without a verified Play Store package ID (AI Utility Hub, HelpsNest, Invoice Maker, and Flatly), add the official icon manually using the exact filename referenced by README.md.
3. Commit the generated image files along with README.md.

For web project logos, README uses a favicon endpoint. If you want fully controlled branding, download each official logo into `assets/projects/` and replace the favicon URL with a relative image path.
